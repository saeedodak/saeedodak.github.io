# cp-practice-list

I am learning how to design a blog page! and I'm going to create a cp(competitive programming) practice problem set and references. anyway It's ganna be awesome.
